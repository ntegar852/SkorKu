package id.ac.umko.skorku;

import android.app.Application;

import androidx.appcompat.app.AppCompatDelegate;

/**
 * Dijalankan sekali saat proses aplikasi dimulai (termasuk setelah force stop).
 * Di sini tema gelap/terang dipulihkan dari SharedPreferences.
 */
public class SkorApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        boolean dark = new PrefsManager(this).isDarkMode();
        AppCompatDelegate.setDefaultNightMode(
                dark ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
    }
}
