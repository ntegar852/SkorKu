package id.ac.umko.skorku;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {

    private MatchDbHelper db;
    private final List<MatchDbHelper.Match> matches = new ArrayList<>();
    private ArrayAdapter<MatchDbHelper.Match> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        db = new MatchDbHelper(this);

        ListView lvMatches = findViewById(R.id.lvMatches);
        lvMatches.setEmptyView(findViewById(R.id.tvEmpty));

        adapter = new ArrayAdapter<MatchDbHelper.Match>(this, R.layout.item_match, matches) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View row = convertView;
                if (row == null) {
                    row = LayoutInflater.from(getContext())
                            .inflate(R.layout.item_match, parent, false);
                }
                MatchDbHelper.Match m = getItem(position);
                ((TextView) row.findViewById(R.id.tvResult)).setText(
                        m.teamA + "  " + m.scoreA + " - " + m.scoreB + "  " + m.teamB);
                ((TextView) row.findViewById(R.id.tvDate)).setText(m.playedAt);
                return row;
            }
        };
        lvMatches.setAdapter(adapter);

        lvMatches.setOnItemLongClickListener((parent, view, position, id) -> {
            db.deleteMatch(matches.get(position).id);
            loadMatches();
            Toast.makeText(this, "Riwayat dihapus", Toast.LENGTH_SHORT).show();
            return true;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadMatches();
    }

    private void loadMatches() {
        matches.clear();
        matches.addAll(db.getAllMatches());
        adapter.notifyDataSetChanged();
    }
}
