package id.ac.umko.skorku;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Pembungkus SharedPreferences. Semua akses pengaturan lewat class ini,
 * jadi nama file dan key hanya ada di satu tempat.
 */
public class PrefsManager {

    private static final String FILE_NAME = "skorku_prefs";
    private static final String KEY_TEAM_A = "team_a";
    private static final String KEY_TEAM_B = "team_b";
    private static final String KEY_TARGET = "target_score";
    private static final String KEY_VIBRATE = "vibrate";
    private static final String KEY_DARK_MODE = "dark_mode";

    public static final int DEFAULT_TARGET = 21;
    public static final int MIN_TARGET = 1;
    public static final int MAX_TARGET = 99;

    private final SharedPreferences prefs;

    public PrefsManager(Context context) {
        prefs = context.getApplicationContext()
                .getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE);
    }

    public String getTeamA() {
        return prefs.getString(KEY_TEAM_A, "Tim A");
    }

    public void setTeamA(String name) {
        prefs.edit().putString(KEY_TEAM_A, name).apply();
    }

    public String getTeamB() {
        return prefs.getString(KEY_TEAM_B, "Tim B");
    }

    public void setTeamB(String name) {
        prefs.edit().putString(KEY_TEAM_B, name).apply();
    }

    public int getTargetScore() {
        return prefs.getInt(KEY_TARGET, DEFAULT_TARGET);
    }

    public void setTargetScore(int target) {
        prefs.edit().putInt(KEY_TARGET, target).apply();
    }

    public boolean isVibrate() {
        return prefs.getBoolean(KEY_VIBRATE, true);
    }

    public void setVibrate(boolean enabled) {
        prefs.edit().putBoolean(KEY_VIBRATE, enabled).apply();
    }

    public boolean isDarkMode() {
        return prefs.getBoolean(KEY_DARK_MODE, false);
    }

    public void setDarkMode(boolean enabled) {
        prefs.edit().putBoolean(KEY_DARK_MODE, enabled).apply();
    }
}
