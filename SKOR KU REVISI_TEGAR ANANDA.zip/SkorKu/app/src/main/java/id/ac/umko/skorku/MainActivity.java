package id.ac.umko.skorku;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String STATE_A = "score_a";
    private static final String STATE_B = "score_b";

    private PrefsManager prefs;
    private MatchDbHelper db;

    private TextView tvNameA, tvNameB, tvScoreA, tvScoreB, tvStatus;
    private Button btnPlusA, btnMinusA, btnPlusB, btnMinusB, btnSave;

    // Skor yang sedang berjalan hanya ada di memori. Skor baru disimpan ke
    // database saat pertandingan disimpan.
    private int scoreA = 0;
    private int scoreB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = new PrefsManager(this);
        db = new MatchDbHelper(this);

        if (savedInstanceState != null) {
            scoreA = savedInstanceState.getInt(STATE_A, 0);
            scoreB = savedInstanceState.getInt(STATE_B, 0);
        }

        tvNameA = findViewById(R.id.tvNameA);
        tvNameB = findViewById(R.id.tvNameB);
        tvScoreA = findViewById(R.id.tvScoreA);
        tvScoreB = findViewById(R.id.tvScoreB);
        tvStatus = findViewById(R.id.tvStatus);
        btnPlusA = findViewById(R.id.btnPlusA);
        btnMinusA = findViewById(R.id.btnMinusA);
        btnPlusB = findViewById(R.id.btnPlusB);
        btnMinusB = findViewById(R.id.btnMinusB);
        btnSave = findViewById(R.id.btnSave);
        Button btnReset = findViewById(R.id.btnReset);
        Button btnHistory = findViewById(R.id.btnHistory);
        Button btnSettings = findViewById(R.id.btnSettings);

        btnPlusA.setOnClickListener(v -> {
            scoreA++;
            vibrateIfEnabled();
            updateUi();
        });
        btnMinusA.setOnClickListener(v -> {
            if (scoreA > 0) {
                scoreA--;
            }
            updateUi();
        });
        btnPlusB.setOnClickListener(v -> {
            scoreB++;
            vibrateIfEnabled();
            updateUi();
        });
        btnMinusB.setOnClickListener(v -> {
            if (scoreB > 0) {
                scoreB--;
            }
            updateUi();
        });

        btnReset.setOnClickListener(v -> {
            scoreA = 0;
            scoreB = 0;
            updateUi();
        });

        btnSave.setOnClickListener(v -> {
            db.addMatch(prefs.getTeamA(), prefs.getTeamB(), scoreA, scoreB);
            scoreA = 0;
            scoreB = 0;
            updateUi();
            Toast.makeText(this, "Pertandingan disimpan ke riwayat",
                    Toast.LENGTH_SHORT).show();
        });

        btnHistory.setOnClickListener(v ->
                startActivity(new Intent(this, HistoryActivity.class)));
        btnSettings.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));
    }

    /** Dipanggil setiap layar tampil lagi, termasuk saat kembali dari Pengaturan. */
    @Override
    protected void onResume() {
        super.onResume();
        tvNameA.setText(prefs.getTeamA());
        tvNameB.setText(prefs.getTeamB());
        updateUi();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_A, scoreA);
        outState.putInt(STATE_B, scoreB);
    }

    private void updateUi() {
        int target = prefs.getTargetScore();
        tvScoreA.setText(String.valueOf(scoreA));
        tvScoreB.setText(String.valueOf(scoreB));

        String winner = null;
        if (scoreA >= target) {
            winner = prefs.getTeamA();
        } else if (scoreB >= target) {
            winner = prefs.getTeamB();
        }

        if (winner != null) {
            tvStatus.setText("Pemenang: " + winner + "! Simpan pertandingan atau reset.");
        } else {
            tvStatus.setText("Target skor: " + target);
        }

        boolean playing = winner == null;
        btnPlusA.setEnabled(playing);
        btnPlusB.setEnabled(playing);
        btnMinusA.setEnabled(scoreA > 0);
        btnMinusB.setEnabled(scoreB > 0);
        btnSave.setEnabled(scoreA + scoreB > 0);
    }

    @SuppressWarnings("deprecation")
    private void vibrateIfEnabled() {
        if (!prefs.isVibrate()) {
            return;
        }
        Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (vib == null || !vib.hasVibrator()) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            vib.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            vib.vibrate(40);
        }
    }
}
