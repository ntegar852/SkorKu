package id.ac.umko.skorku;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Database SQLite: riwayat pertandingan yang sudah disimpan.
 * Jumlahnya terus bertambah, jadi cocok di database, bukan di SharedPreferences.
 */
public class MatchDbHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "skorku.db";
    private static final int DB_VERSION = 1;
    private static final String TABLE = "matches";

    public static class Match {
        public final long id;
        public final String teamA;
        public final String teamB;
        public final int scoreA;
        public final int scoreB;
        public final String playedAt;

        public Match(long id, String teamA, String teamB, int scoreA, int scoreB,
                     String playedAt) {
            this.id = id;
            this.teamA = teamA;
            this.teamB = teamB;
            this.scoreA = scoreA;
            this.scoreB = scoreB;
            this.playedAt = playedAt;
        }
    }

    public MatchDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "team_a TEXT NOT NULL, "
                + "team_b TEXT NOT NULL, "
                + "score_a INTEGER NOT NULL, "
                + "score_b INTEGER NOT NULL, "
                + "played_at TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    public void addMatch(String teamA, String teamB, int scoreA, int scoreB) {
        String now = new SimpleDateFormat("dd MMM yyyy, HH:mm", new Locale("id", "ID"))
                .format(new Date());
        ContentValues v = new ContentValues();
        v.put("team_a", teamA);
        v.put("team_b", teamB);
        v.put("score_a", scoreA);
        v.put("score_b", scoreB);
        v.put("played_at", now);
        getWritableDatabase().insert(TABLE, null, v);
    }

    public void deleteMatch(long id) {
        getWritableDatabase().delete(TABLE, "id = ?", new String[]{String.valueOf(id)});
    }

    public List<Match> getAllMatches() {
        List<Match> list = new ArrayList<>();
        Cursor c = getReadableDatabase().query(TABLE, null, null, null, null, null, "id DESC");
        try {
            while (c.moveToNext()) {
                list.add(new Match(
                        c.getLong(c.getColumnIndexOrThrow("id")),
                        c.getString(c.getColumnIndexOrThrow("team_a")),
                        c.getString(c.getColumnIndexOrThrow("team_b")),
                        c.getInt(c.getColumnIndexOrThrow("score_a")),
                        c.getInt(c.getColumnIndexOrThrow("score_b")),
                        c.getString(c.getColumnIndexOrThrow("played_at"))));
            }
        } finally {
            c.close();
        }
        return list;
    }
}
