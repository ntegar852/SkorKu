package id.ac.umko.skorku;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        PrefsManager prefs = new PrefsManager(this);

        EditText etTeamA = findViewById(R.id.etTeamA);
        EditText etTeamB = findViewById(R.id.etTeamB);
        EditText etTarget = findViewById(R.id.etTarget);
        Switch swVibrate = findViewById(R.id.swVibrate);
        Switch swDark = findViewById(R.id.swDark);
        Button btnSave = findViewById(R.id.btnSave);

        // Tampilkan nilai yang tersimpan
        etTeamA.setText(prefs.getTeamA());
        etTeamB.setText(prefs.getTeamB());
        etTarget.setText(String.valueOf(prefs.getTargetScore()));
        swVibrate.setChecked(prefs.isVibrate());
        swDark.setChecked(prefs.isDarkMode());

        btnSave.setOnClickListener(v -> {
            String a = etTeamA.getText().toString().trim();
            String b = etTeamB.getText().toString().trim();
            if (a.isEmpty()) {
                a = "Tim A";
            }
            if (b.isEmpty()) {
                b = "Tim B";
            }

            int target = PrefsManager.DEFAULT_TARGET;
            try {
                target = Integer.parseInt(etTarget.getText().toString().trim());
            } catch (NumberFormatException ignored) {
                // pakai nilai default
            }
            if (target < PrefsManager.MIN_TARGET || target > PrefsManager.MAX_TARGET) {
                target = PrefsManager.DEFAULT_TARGET;
            }

            boolean dark = swDark.isChecked();

            prefs.setTeamA(a);
            prefs.setTeamB(b);
            prefs.setTargetScore(target);
            prefs.setVibrate(swVibrate.isChecked());
            prefs.setDarkMode(dark);

            Toast.makeText(this, "Pengaturan disimpan", Toast.LENGTH_SHORT).show();
            AppCompatDelegate.setDefaultNightMode(
                    dark ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
            finish();
        });
    }
}
