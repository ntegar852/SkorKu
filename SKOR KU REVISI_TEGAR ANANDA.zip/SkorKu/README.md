# SkorKu: Penghitung Skor Permainan (Studi Kasus SharedPreferences)

Aplikasi Android (Java) untuk Tugas P10 Pemrograman Mobile. Cocok untuk badminton, futsal, voli, atau permainan apa pun.

## Cara membuka
1. Ekstrak zip ke folder dengan nama sederhana, misalnya `C:\Projects\SkorKu`.
2. Di Android Studio pilih **Open**, lalu pilih folder `SkorKu`.
3. Jika muncul "Please Select Gradle JVM", klik **Use JVM 17**.
4. Tunggu Gradle sync selesai (butuh internet untuk mengunduh Gradle 8.2), lalu Run di HP atau emulator (minSdk 24).

## Cara pakai
- Tekan **+1** / **-1** untuk mengubah skor tiap tim. Saat salah satu tim mencapai batas skor, tombol +1 dikunci dan pemenang ditampilkan.
- **Simpan Pertandingan** memasukkan hasil ke Riwayat, lalu skor di-reset.
- **Riwayat**: daftar pertandingan tersimpan. Tekan lama untuk menghapus.
- **Pengaturan**: nama Tim A dan Tim B, batas skor, getar, dan mode gelap.

## Pembagian penyimpanan data
| Data | Disimpan di | Alasan |
|---|---|---|
| Nama Tim A dan Tim B | SharedPreferences | Dua teks pendek, dipakai di setiap pertandingan |
| Batas skor kemenangan | SharedPreferences | Satu angka pengaturan |
| Getar saat skor bertambah | SharedPreferences | Pilihan true/false |
| Mode gelap | SharedPreferences | Pilihan true/false |
| Riwayat pertandingan (tim, skor, waktu) | SQLite | Jumlahnya terus bertambah dan perlu ditampilkan sebagai daftar |
| Skor yang sedang berjalan | Tidak disimpan permanen (memori) | Bersifat sementara. Hanya hasil akhir yang perlu disimpan |

## Alur kerja SharedPreferences
- `PrefsManager` membungkus `getSharedPreferences("skorku_prefs", MODE_PRIVATE)`.
- `SettingsActivity` menyimpan nilai lewat `apply()` (asinkron, tidak memblokir UI).
- `MainActivity.onResume()` membaca ulang nama tim dan batas skor, jadi perubahan langsung terlihat saat kembali dari Pengaturan.
- `SkorApp.onCreate()` memulihkan mode gelap saat proses dimulai.

## Cara membuktikan data bertahan (poin 5)
1. Buka Pengaturan: ganti nama Tim A dan Tim B, ubah batas skor (misalnya 11), nyalakan mode gelap, lalu Simpan.
2. Di HP: Pengaturan > Aplikasi > SkorKu > **Paksa berhenti** (Force stop).
3. Buka aplikasi lagi: nama tim, batas skor ("Target skor: 11"), dan tema gelap tetap sama.
4. Rekam seluruh langkah ini dengan screen recording.

Catatan: skor yang sedang berjalan akan kembali ke 0 setelah Force Stop. Ini disengaja, dan bisa dipakai sebagai contoh poin 3: data sementara tidak perlu disimpan permanen.

## Naskah video (sekitar 60 detik, vertikal 9:16)
1. (0-8 dtk) Tunjukkan layar aplikasi. "Halo, ini SkorKu, aplikasi penghitung skor permainan yang saya buat."
2. (8-18 dtk) Masalah: "Saat bermain, skor sering dicatat manual di kertas dan mudah salah. Aplikasi ini menghitung skor dan menentukan pemenang otomatis."
3. (18-30 dtk) Tunjukkan Pengaturan. "Nama tim, batas skor, getar, dan mode gelap disimpan di SharedPreferences karena kecil dan sederhana."
4. (30-40 dtk) Tunjukkan Riwayat. "Riwayat pertandingan disimpan di SQLite karena jumlahnya terus bertambah."
5. (40-50 dtk) Tunjukkan kode `PrefsManager`. "Penyimpanan lewat apply(), lalu dibaca lagi di onResume()."
6. (50-60 dtk) Force stop, buka lagi. "Pengaturan tetap ada. Menurut kamu, data apa lagi yang cocok di SharedPreferences?"

## Template komentar pengumpulan tugas
Ganti bagian dalam [ ].

```
SharedPreferences pada Aplikasi Mobile – Penghitung Skor Permainan "SkorKu"
Tugas P10 Pemrograman Mobile · Prodi STI · Universitas Muhammadiyah Kotabumi
Nama : [Nama lengkap]
NIM : [NIM]
Kelas : [Kelas]
Dosen : Ryan Aji Wijaya, S.Kom., M.M.S.I
Keterangan:
1 Aplikasi menggantikan pencatatan skor manual di kertas: menghitung skor dua tim, menentukan pemenang saat batas skor tercapai, dan menyimpan riwayat pertandingan.
2 SharedPreferences: nama Tim A dan Tim B, batas skor kemenangan, getar, dan mode gelap. Alasannya datanya kecil, berupa nilai tunggal, dan dibaca setiap aplikasi dibuka.
3 SQLite: riwayat pertandingan (tim, skor akhir, waktu) karena jumlahnya terus bertambah. Skor yang sedang berjalan sengaja tidak disimpan permanen karena bersifat sementara.
4 PrefsManager membungkus getSharedPreferences, menyimpan dengan apply() di SettingsActivity, dan dibaca ulang di onResume() MainActivity.
5 Bukti: setelah Force Stop dan membuka ulang aplikasi, nama tim, batas skor, dan tema gelap tetap tersimpan (lihat video).
Kode: [link repositori GitHub]
Menurut kalian, data apa lagi di aplikasi mobile yang cocok disimpan di SharedPreferences?
#android #java #pemrogramanmobile #sharedpreferences #umko
```
